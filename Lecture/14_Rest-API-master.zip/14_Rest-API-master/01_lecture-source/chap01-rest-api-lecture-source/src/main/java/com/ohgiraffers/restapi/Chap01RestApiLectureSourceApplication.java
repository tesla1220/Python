package com.ohgiraffers.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap01RestApiLectureSourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap01RestApiLectureSourceApplication.class, args);
    }

}
